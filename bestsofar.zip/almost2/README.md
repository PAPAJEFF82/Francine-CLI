
# Francine AI - Command-Line Edition

**V5.0.0 DEVELOPED BY: JEFF BULGER**

A powerful, context-aware, modular AI agent that runs locally in your terminal. This tool is designed to be a true "codex," capable of interacting with your local file system, executing shell commands, and more, with a stable and clean interface.

> **⚠️ Security Warning:** This tool gives the AI agent the ability to read files and execute any command on your computer. This is extremely powerful and potentially dangerous. Only use this tool if you understand the risks and are closely monitoring the agent's actions.

## Core Features

*   **Stable Scrolling UI:** A clean, classic terminal interface that is robust and does not crash.
*   **System-Wide Command:** Install once and run `francine` from any directory.
*   **True Local Access:** The agent can read files and execute shell commands.
*   **Agent Thoughts Toggle:** Use the `/thoughts` command to show or hide the agent's reasoning process.
*   **Image Generation:** Create images from text prompts (requires Gemini configuration).
*   **Persistent Configuration:** One-time setup for your AI models, saved to `~/.francine/config.json`.
*   **Flexible Model Support:** Connect to Google Gemini, any OpenAI-compatible API (Groq, Anthropic, etc.), or a local [Ollama](https://ollama.com/) instance.

---

## Installation

You only need to do this once.

1.  **Prerequisites:** Ensure you have **[Node.js](https://nodejs.org/en/download)** (v20 or higher) installed.
2.  **Clone the Repository:**
    ```bash
    git clone https://github.com/your-username/francine-ai-cli.git
    cd francine-ai-cli
    ```
3.  **Install Dependencies & Build:**
    This downloads all the required libraries and compiles the code.
    ```bash
    npm install
    npm run build
    ```
4.  **Link the Command (Optional, for Global Use):**
    This creates a global `francine` command that points to your project folder.
    ```bash
    npm link
    ```
5.  **Done!** You can now run `francine` from anywhere (if linked), or `npm start` from the project directory.

---

## Usage

Run the application:
```bash
# If you used 'npm link'
francine

# If running locally
npm start
```
You will be greeted by the header and a prompt. Type your request and press Enter.

### Slash Commands
- `/exit`: Quit the application.
- `/config`: Re-run the model configuration wizard (restarts app).
- `/reset`: Delete your current configuration file (restarts app).
- `/thoughts`: Toggle visibility of the agent's step-by-step reasoning.
- `/clear`: Clear the current conversation history.
- `/help`: Display a list of available commands.
