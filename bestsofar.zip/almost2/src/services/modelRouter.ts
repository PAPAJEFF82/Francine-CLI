
import { ModelConfig, AIModelType, CloudConfig, LocalConfig, CloudProvider, GeminiConfig, OpenAIConfig, GroqConfig, AnthropicConfig, MetaConfig, OtherConfig } from '../types';
import { LLMClient } from '../models/_base';
import { GeminiClient } from '../models/gemini';
import { OllamaClient } from '../models/ollama';
import { OpenAICompatibleClient } from '../models/openaiCompatible';
import { AnthropicClient } from '../models/anthropic';

function getClient(config: ModelConfig): LLMClient {
    switch(config.type) {
        case AIModelType.CLOUD:
            const cloudConfig = config as CloudConfig;
            
            // Handle proxied Gemini connections by routing them to the OpenAI-compatible client
            if (cloudConfig.provider === CloudProvider.GEMINI && (cloudConfig as GeminiConfig).baseUrl) {
                return new OpenAICompatibleClient(cloudConfig as GeminiConfig);
            }

            switch(cloudConfig.provider) {
                case CloudProvider.GEMINI:
                    return new GeminiClient(cloudConfig as GeminiConfig);
                case CloudProvider.OPENAI:
                case CloudProvider.GROQ:
                case CloudProvider.META:
                case CloudProvider.OTHER:
                    return new OpenAICompatibleClient(cloudConfig as OpenAIConfig | GroqConfig | MetaConfig | OtherConfig);
                case CloudProvider.ANTHROPIC:
                    return new AnthropicClient(cloudConfig as AnthropicConfig);
                default:
                    // This will catch if a new provider is added to the enum but not here
                    const _exhaustiveCheck: never = cloudConfig;
                    throw new Error(`Unsupported cloud provider: ${(_exhaustiveCheck as any).provider}`);
            }
        case AIModelType.LOCAL:
            return new OllamaClient(config as LocalConfig);
        default:
            throw new Error("Unsupported model type specified in config.");
    }
}

export function generateAgentResponse(
  history: { role: string; parts: { text: string }[] }[],
  systemInstruction: string,
  config: ModelConfig
): Promise<string> {
    const client = getClient(config);
    return client.generate(history, systemInstruction);
}
