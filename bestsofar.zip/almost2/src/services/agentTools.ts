import * as fs from 'fs/promises';
import * as path from 'path';
import * as os from 'os';
import { exec } from 'child_process';
import { promisify } from 'util';
import { cwd } from 'node:process';
import { GoogleGenAI } from '@google/genai';
import { ModelConfig, CloudProvider, GeminiConfig } from '../types';

const execAsync = promisify(exec);

async function list_files(dirPath: string): Promise<string> {
  try {
    const resolvedPath = path.resolve(dirPath);
    const files = await fs.readdir(resolvedPath, { withFileTypes: true });
    if (files.length === 0) {
        return `Directory '${dirPath}' is empty.`;
    }
    return files.map(file => (file.isDirectory() ? `${file.name}/` : file.name)).join('\n');
  } catch (error: any) {
    if (error.code === 'ENOENT') {
      return `Error: Directory not found at ${dirPath}`;
    }
    throw error;
  }
}

async function read_file(filePath: string): Promise<string> {
  try {
    const resolvedPath = path.resolve(filePath);
    return await fs.readFile(resolvedPath, 'utf-8');
  } catch (error: any) {
    if (error.code === 'ENOENT') {
      return `Error: File not found at ${filePath}`;
    } else if (error.code === 'EISDIR') {
        return `Error: Path '${filePath}' is a directory, not a file.`;
    }
    throw error;
  }
}

async function execute_shell_command(command: string): Promise<string> {
  if (!command) {
      return "Error: No command provided to execute.";
  }
  
  try {
    const { stdout, stderr } = await execAsync(command, { cwd: cwd() });
    if (stderr) {
      return `Execution finished with standard error.\nSTDERR:\n${stderr}\n\nSTDOUT:\n${stdout}`;
    }
    return stdout || "Command executed successfully with no output.";
  } catch (error: any) {
    let errorMessage = `Error executing command: "${command}".\n`;
    if (error.stderr) errorMessage += `STDERR: ${error.stderr}\n`;
    if (error.stdout) errorMessage += `STDOUT: ${error.stdout}\n`;
    if (error.message) errorMessage += `MESSAGE: ${error.message}`;
    return errorMessage;
  }
}

async function generate_image(prompt: string, config: ModelConfig): Promise<string> {
    if (config.type !== 'Cloud' || config.provider !== CloudProvider.GEMINI) {
        return "Error: Image generation is currently only supported with a configured Gemini model.";
    }
    const geminiConfig = config as GeminiConfig;

    try {
        const ai = new GoogleGenAI({apiKey: geminiConfig.apiKey});
        const response = await ai.models.generateImages({
            model: 'imagen-3.0-generate-002',
            prompt,
            config: {
              numberOfImages: 1,
              outputMimeType: 'image/png'
            },
        });

        const base64Image = response.generatedImages?.[0]?.image?.imageBytes;
        if (!base64Image) {
            return "Error: API did not return an image.";
        }
        
        const desktopPath = path.join(os.homedir(), 'Desktop');
        await fs.mkdir(desktopPath, { recursive: true }); // Ensure Desktop directory exists

        const filename = `francine-image-${Date.now()}.png`;
        const imagePath = path.join(desktopPath, filename);
        await fs.writeFile(imagePath, base64Image, 'base64');

        return `Image successfully generated and saved to your Desktop at ${imagePath}`;
    } catch (error) {
        return error instanceof Error ? `Gemini Image API Error: ${error.message}`: "An unknown error occurred during image generation.";
    }
}

const availableTools: { [key: string]: (params: any, config: ModelConfig) => Promise<string> } = {
  list_files: (params, config) => list_files(params.path),
  read_file: (params, config) => read_file(params.path),
  execute_shell_command: (params, config) => execute_shell_command(params.command),
  generate_image: (params, config) => generate_image(params.prompt, config),
};

export async function executeTool(toolName: string, parameters: Record<string, any>, modelConfig: ModelConfig): Promise<string> {
  const tool = availableTools[toolName];
  if (!tool) {
    return `Error: Tool "${toolName}" not found.`;
  }
  try {
    return await tool(parameters, modelConfig);
  } catch (error) {
    return error instanceof Error ? `Error executing ${toolName}: ${error.message}` : `An unknown error occurred in ${toolName}.`;
  }
}