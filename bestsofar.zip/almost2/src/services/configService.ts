
import * as fs from 'fs-extra';
import * as path from 'path';
import * as os from 'os';
import { ModelConfig } from '../types';

const CONFIG_DIR = path.join(os.homedir(), '.francine');
const CONFIG_FILE_PATH = path.join(CONFIG_DIR, 'config.json');

export async function saveConfig(config: ModelConfig): Promise<void> {
    try {
        await fs.ensureDir(CONFIG_DIR);
        await fs.writeJson(CONFIG_FILE_PATH, config, { spaces: 2 });
    } catch (error) {
        console.error('Error saving configuration:', error);
        throw new Error('Could not save configuration file.');
    }
}

export async function loadConfig(): Promise<ModelConfig | null> {
    try {
        if (await fs.pathExists(CONFIG_FILE_PATH)) {
            const config = await fs.readJson(CONFIG_FILE_PATH);
            return config as ModelConfig;
        }
        return null;
    } catch (error) {
        console.error('Error loading configuration:', error);
        return null;
    }
}

export async function deleteConfig(): Promise<void> {
    try {
        if (await fs.pathExists(CONFIG_FILE_PATH)) {
            await fs.remove(CONFIG_FILE_PATH);
        }
    } catch (error) {
        console.error('Error deleting configuration:', error);
        throw new Error('Could not delete configuration file.');
    }
}
