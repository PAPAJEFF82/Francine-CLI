import { ModelConfig, Role, ToolCall, HistoryItem } from '../types';
import { generateAgentResponse } from './modelRouter';
import { executeTool } from './agentTools';
import { AGENT_SYSTEM_PROMPT } from '../constants';
import chalk from 'chalk';
import { stdout } from 'node:process';

const MAX_AGENT_ITERATIONS = 10;

function isToolCall(obj: any): obj is ToolCall {
    return obj && typeof obj.toolName === 'string' && typeof obj.parameters === 'object';
}

function parseAgentResponse(responseText: string): { thought: string | null; toolCall: ToolCall | null } {
    const thoughtMatch = responseText.match(/<thought>([\s\S]*?)<\/thought>/s);
    const thought = thoughtMatch ? thoughtMatch[1].trim() : null;

    let textAfterThought = thought ? responseText.substring(responseText.indexOf('</thought>') + 10) : responseText;
    textAfterThought = textAfterThought.trim();

    const jsonRegex = /(?:```json\s*)?({[\s\S]*?})(?:\s*```)?/;
    const jsonMatch = textAfterThought.match(jsonRegex);

    // If the model provides what looks like a JSON tool call, we expect it to be one.
    if (jsonMatch && jsonMatch[1]) {
        try {
            const parsed = JSON.parse(jsonMatch[1]);
            if (isToolCall(parsed)) {
                return { thought, toolCall: parsed };
            }
        } catch (e) {
            // It looked like JSON, but failed to parse. This is an invalid action.
            // Let it fall through to be treated as a final answer.
        }
    }

    // If no valid JSON tool call is present, treat the entire non-thought text as the final answer.
    if (textAfterThought) {
        return { thought, toolCall: { toolName: 'finish', parameters: { response: textAfterThought } } };
    }

    // If we only have a thought but no action, it's an incomplete response.
    return { thought, toolCall: null };
}

export async function runAgentLoop(
  history: HistoryItem[],
  modelConfig: ModelConfig,
  showThoughts: boolean
): Promise<string | null> {
  
  // Convert the simple history to the format the LLM expects
  let currentHistory: { role: string; parts: { text: string }[] }[] = history.map(h => ({ role: h.role, parts: [{ text: h.text }] }));

  for (let i = 0; i < MAX_AGENT_ITERATIONS; i++) {
    try {
        if (!showThoughts) stdout.write(chalk.gray('Agent is working...'));
        const responseText = await generateAgentResponse(currentHistory, AGENT_SYSTEM_PROMPT, modelConfig);
        if (!showThoughts) stdout.write('\r' + ' '.repeat(20) + '\r');
        
        const { thought, toolCall } = parseAgentResponse(responseText);

        if (showThoughts && thought) {
            console.log(chalk.yellow('\n🤔 THOUGHT: ') + chalk.gray(thought));
        }
        
        currentHistory.push({ role: Role.ASSISTANT, parts: [{ text: responseText }] });

        if (toolCall) {
            if (toolCall.toolName === 'finish') {
                return toolCall.parameters.response || "Agent finished with no response.";
            }

            if (showThoughts) {
                const params = JSON.stringify(toolCall.parameters);
                console.log(chalk.blue('⚡️ ACTION: ') + chalk.cyan(toolCall.toolName) + ' with params ' + chalk.magenta(params));
            }
            
            const toolOutput = await executeTool(toolCall.toolName, toolCall.parameters, modelConfig);
            
            if (showThoughts) {
                 console.log(chalk.green('✔️ RESULT: ') + chalk.gray(toolOutput));
            }
            
            // Add tool result to history for the next loop
            currentHistory.push({ role: Role.TOOL, parts: [{ text: `<tool_result>\n${toolOutput}\n</tool_result>` }] });

        } else {
            console.log(chalk.red("\nAgent Error: Could not determine a valid next action or final answer."));
            console.log(chalk.gray("Full model response:\n"), responseText)
            return null;
        }
    } catch (error) {
        if (!showThoughts) stdout.write('\r' + ' '.repeat(20) + '\r');
        const errorMessage = error instanceof Error ? error.message : String(error);
        console.error(chalk.redBright('\nAn error occurred during the agent loop: ' + errorMessage));
        return `An error occurred: ${errorMessage}`;
    }
  }

  console.log(chalk.red(`\nAgent reached maximum iterations (${MAX_AGENT_ITERATIONS}) without finishing. Aborting.`));
  return null;
}