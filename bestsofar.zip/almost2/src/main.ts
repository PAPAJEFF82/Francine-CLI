
import { createInterface, Interface as ReadlineInterface } from 'readline/promises';
import { readJsonSync } from 'fs-extra';
import path from 'path';
import chalk from 'chalk';
import { stdout, stdin, exit } from 'node:process';
import { runAgentLoop } from './services/agentService';
import { ModelConfig, AIModelType, CloudProvider, GeminiConfig, OpenAIConfig, GroqConfig, AnthropicConfig, OtherConfig, MetaConfig, HistoryItem, Role } from './types';
import { ASCII_ART_HEADER } from './constants';
import { loadConfig, saveConfig, deleteConfig } from './services/configService';

const { version } = readJsonSync(path.join(__dirname, '../package.json'));

let showThoughts = false;
let conversationHistory: HistoryItem[] = [];

async function configureModel(rl: ReadlineInterface): Promise<ModelConfig | null> {
    console.log(chalk.cyan('\n--- Model Configuration ---'));
    const typeChoice = await rl.question('Select Model Type (' + chalk.yellow('1: Cloud') + ', ' + chalk.yellow('2: Local') + '): ');

    if (typeChoice.trim() === '2') {
        const baseUrl = await rl.question('Enter Local API Base URL (e.g., http://localhost:11434): ');
        const modelName = await rl.question('Enter Model Name (e.g., llama3): ');
        return {
            type: AIModelType.LOCAL,
            baseUrl: baseUrl || 'http://localhost:11434',
            modelName: modelName || 'llama3',
        };
    } else {
        console.log(chalk.cyan('\nSelect a Cloud Provider:'));
        console.log(chalk.yellow('1: Gemini'));
        console.log(chalk.yellow('2: OpenAI'));
        console.log(chalk.yellow('3: Groq'));
        console.log(chalk.yellow('4: Anthropic'));
        console.log(chalk.yellow('5: Meta (OpenAI-compatible)'));
        console.log(chalk.yellow('6: Other (Custom OpenAI-compatible)'));
        const providerChoice = await rl.question('Enter your choice: ');

        let apiKey: string, modelName: string, baseUrl: string;

        switch (providerChoice.trim()) {
            case '1': // Gemini
                apiKey = await rl.question('Enter your Google Gemini API Key: ');
                if (!apiKey) { console.error(chalk.red("API Key is required.")); return null; }
                modelName = await rl.question('Enter Model Name (optional, press Enter for gemini-2.5-flash): ');
                 if (!modelName) {
                    modelName = 'gemini-2.5-flash';
                }
                baseUrl = await rl.question('Enter Base URL (optional, for proxies): ');
                return {
                    type: AIModelType.CLOUD,
                    provider: CloudProvider.GEMINI,
                    apiKey,
                    modelName,
                    baseUrl: baseUrl || undefined,
                } as GeminiConfig;
            
            case '2': // OpenAI
                apiKey = await rl.question('Enter your OpenAI API Key: ');
                if (!apiKey) { console.error(chalk.red("API Key is required.")); return null; }
                modelName = await rl.question('Enter Model Name (e.g., gpt-4-turbo): ');
                if (!modelName) { console.error(chalk.red("Model Name is required.")); return null; }
                baseUrl = await rl.question('Enter Base URL (optional, press Enter for default): ');
                return {
                    type: AIModelType.CLOUD,
                    provider: CloudProvider.OPENAI,
                    apiKey,
                    modelName,
                    baseUrl: baseUrl || undefined,
                } as OpenAIConfig;

            case '3': // Groq
                apiKey = await rl.question('Enter your Groq API Key: ');
                if (!apiKey) { console.error(chalk.red("API Key is required.")); return null; }
                modelName = await rl.question('Enter Model Name (e.g., llama3-70b-8192): ');
                if (!modelName) { console.error(chalk.red("Model Name is required.")); return null; }
                return {
                    type: AIModelType.CLOUD,
                    provider: CloudProvider.GROQ,
                    apiKey,
                    modelName,
                } as GroqConfig;

            case '4': // Anthropic
                apiKey = await rl.question('Enter your Anthropic API Key: ');
                if (!apiKey) { console.error(chalk.red("API Key is required.")); return null; }
                modelName = await rl.question('Enter Model Name (e.g., claude-3-opus-20240229): ');
                 if (!modelName) { console.error(chalk.red("Model Name is required.")); return null; }
                return {
                    type: AIModelType.CLOUD,
                    provider: CloudProvider.ANTHROPIC,
                    apiKey,
                    modelName,
                } as AnthropicConfig;
            
            case '5': // Meta
            case '6': // Other
                const provider = providerChoice.trim() === '5' ? CloudProvider.META : CloudProvider.OTHER;
                console.log(chalk.cyan(`\n--- Configuring ${provider} Provider ---`));
                apiKey = await rl.question('Enter your API Key: ');
                
                while (true) {
                    baseUrl = await rl.question('Enter the full Base URL for the API: ');
                    try {
                        new URL(baseUrl);
                        break;
                    } catch (e) {
                        console.error(chalk.red("Invalid URL. Please include http:// or https://"));
                    }
                }

                modelName = await rl.question('Enter the Model Name: ');
                if (!apiKey || !baseUrl || !modelName) {
                    console.error(chalk.red("API Key, Base URL, and Model Name are all required."));
                    return null;
                }
                if (provider === CloudProvider.META){
                    return { type: AIModelType.CLOUD, provider, apiKey, baseUrl, modelName } as MetaConfig;
                }
                return { type: AIModelType.CLOUD, provider, apiKey, baseUrl, modelName } as OtherConfig;
            
            default:
                console.error(chalk.red("Invalid selection."));
                return null;
        }
    }
}

function printFooter() {
    // A more realistic context usage estimation (very rough)
    const contextPercentage = Math.min(Math.round((JSON.stringify(conversationHistory).length / 32000) * 100), 100);
    const thoughtsStatus = chalk.gray(`Thoughts: ${showThoughts ? chalk.green('ON') : chalk.red('OFF')}`);
    const contextStatus = chalk.gray(`Context: ~${contextPercentage}%`);
    const footerText = `\n${chalk.dim('─'.repeat(stdout.columns || 80))}\n ${chalk.bold(`v${version}`)} | ${contextStatus} | ${thoughtsStatus} (use /thoughts to toggle) `;
    console.log(footerText);
}

function printHelp() {
    console.log(chalk.cyan('\nAvailable Commands:'));
    console.log(`  ${chalk.bold('/exit')}\t\t- Quit the application.`);
    console.log(`  ${chalk.bold('/config')}\t- Re-run the model configuration wizard.`);
    console.log(`  ${chalk.bold('/reset')}\t\t- Delete your current configuration.`);
    console.log(`  ${chalk.bold('/thoughts')}\t- Toggle visibility of the agent's reasoning process.`);
    console.log(`  ${chalk.bold('/clear')}\t\t- Clear the conversation history.`);
    console.log(`  ${chalk.bold('/help')}\t\t- Display this help message.`);
}

async function main() {
    console.log(chalk.cyan.bold(ASCII_ART_HEADER));
    const devCredit = chalk.bold(`V${version} DEVELOPED BY: JEFF BULGER`);
    console.log(`${' '.repeat(Math.max(0, ((stdout.columns || 80) - devCredit.length) / 2))}${devCredit}\n`);

    const rl = createInterface({ input: stdin, output: stdout });

    let activeModelConfig = await loadConfig();

    if (!activeModelConfig) {
        console.log('No configuration found. Starting interactive setup...');
        activeModelConfig = await configureModel(rl);
        if (activeModelConfig) {
            await saveConfig(activeModelConfig);
            console.log(chalk.green('\n✅ Configuration saved successfully! Please restart the application.'));
        } else {
            console.error(chalk.red('Configuration failed. Exiting.'));
        }
        rl.close();
        return;
    } 

    console.log(chalk.green('✅ Loaded existing configuration.'));
    const modelDesc = activeModelConfig.type === AIModelType.LOCAL
        ? `${activeModelConfig.modelName}`
        : `${activeModelConfig.provider} - ${activeModelConfig.modelName}`;
    console.log(`Using model: ${chalk.blue(modelDesc)}`);
    printHelp();
    
    while (true) {
        printFooter();
        const userInput = await rl.question(chalk.bold('> '));
        const command = userInput.toLowerCase().trim();

        let needsContinue = false;
        switch (command) {
            case '/exit':
                rl.close();
                console.log('\nGoodbye!');
                return;
            case '/config':
                console.log('Restarting to re-configure...');
                exit(0); // Simple restart
            case '/reset':
                 console.log('Restarting to reset configuration...');
                 await deleteConfig();
                 exit(0);
            case '/thoughts':
                showThoughts = !showThoughts;
                console.log(chalk.yellow(`Agent thoughts are now ${showThoughts ? 'ON' : 'OFF'}.`));
                needsContinue = true;
                break;
            case '/clear':
                conversationHistory = [];
                console.clear();
                console.log(chalk.yellow('Conversation history cleared.'));
                needsContinue = true;
                break;
            case '/help':
                printHelp();
                needsContinue = true;
                break;
        }
        if (needsContinue) continue;
        
        if (userInput.trim()) {
            conversationHistory.push({ role: Role.USER, text: userInput });
            const finalAnswer = await runAgentLoop(conversationHistory, activeModelConfig, showThoughts);

            if (finalAnswer) {
                console.log(chalk.cyanBright.bold('\nFrancine:'));
                console.log(finalAnswer);
                conversationHistory.push({ role: Role.ASSISTANT, text: finalAnswer });
            } else {
                console.log(chalk.red('The agent could not produce a final answer.'));
            }
        }
    }
}

main().catch(err => {
    console.error(chalk.redBright('\n--- A fatal error occurred ---'));
    console.error(err);
    exit(1);
});