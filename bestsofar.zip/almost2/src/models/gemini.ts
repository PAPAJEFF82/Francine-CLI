
import { GoogleGenAI } from "@google/genai";
import { GeminiConfig } from "../types";
import { LLMClient } from "./_base";

export class GeminiClient implements LLMClient {
    public config: GeminiConfig;
    private ai: GoogleGenAI;

    constructor(config: GeminiConfig) {
        const apiKey = config.apiKey || process.env.API_KEY;
        if (!apiKey) {
          throw new Error("Gemini API key is not configured. Pass it to the constructor or set the API_KEY environment variable.");
        }
        this.config = { ...config, apiKey };
        this.ai = new GoogleGenAI({ apiKey: this.config.apiKey });
    }

    async generate(
        history: { role: string; parts: { text: string }[] }[],
        systemInstruction: string
    ): Promise<string> {
        try {
            const response = await this.ai.models.generateContent({
                model: this.config.modelName,
                contents: history,
                config: {
                  systemInstruction,
                },
            });
            return response.text ?? '';
        } catch (e) {
            const errorMessage = e instanceof Error ? e.message : "An unknown error occurred with the agent model.";
            throw new Error(`Gemini API Error: ${errorMessage}`);
        }
    }
}
