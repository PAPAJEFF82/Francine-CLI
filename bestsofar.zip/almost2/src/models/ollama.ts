
import { LocalConfig } from "../types";
import { LLMClient } from "./_base";

export class OllamaClient implements LLMClient {
    public config: LocalConfig;

    constructor(config: LocalConfig) {
        this.config = config;
    }

    async generate(
        history: { role: string; parts: { text: string }[] }[],
        systemInstruction: string
    ): Promise<string> {
        const messages = history.map(h => ({
            role: h.role === 'user' ? 'user' : 'assistant',
            content: h.parts.map(p => p.text).join('\n')
        }));
        
        const response = await fetch(`${this.config.baseUrl}/api/chat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: this.config.modelName,
                system: systemInstruction,
                messages: messages,
                stream: false,
            }),
        });

        if (!response.ok) {
            const errorBody = await response.text();
            throw new Error(`Ollama API error (${response.status}): ${errorBody}`);
        }

        const result = await response.json();
        if (result.message && result.message.content) {
            return result.message.content;
        }
        throw new Error("Invalid response structure from Ollama chat API.");
    }
}
