
import { AnthropicConfig } from "../types";
import { LLMClient } from "./_base";

const ANTHROPIC_API_BASE = 'https://api.anthropic.com/v1';
const ANTHROPIC_VERSION = '2023-06-01';

export class AnthropicClient implements LLMClient {
    public config: AnthropicConfig;

    constructor(config: AnthropicConfig) {
        if (!config.apiKey) {
          throw new Error("Anthropic API key is not configured.");
        }
        this.config = config;
    }
    
    private transformHistory(history: { role: string; parts: { text: string }[] }[]) {
        return history.map(h => ({
            role: h.role as 'user' | 'assistant',
            content: h.parts.map(p => p.text).join('\n')
        })).filter(h => h.role === 'user' || h.role === 'assistant');
    }

    private async handleErrorResponse(response: Response) {
        let errorBody = await response.text();
        try {
            const errorJson = JSON.parse(errorBody);
            if (errorJson.error && errorJson.error.message) {
                errorBody = errorJson.error.message;
            }
        } catch (e) { /* Not a JSON error, use the raw text */ }
        const statusText = response.status === 401 ? ' (Invalid API Key?)'
                         : response.status === 429 ? ' (Rate Limit Exceeded)'
                         : '';
        throw new Error(`Anthropic API error (${response.status}${statusText}): ${errorBody}`);
    }
    
    async generate(
        history: { role: string; parts: { text: string }[] }[],
        systemInstruction: string
    ): Promise<string> {
        const messages = this.transformHistory(history);
        const response = await fetch(`${ANTHROPIC_API_BASE}/messages`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': this.config.apiKey,
                'anthropic-version': ANTHROPIC_VERSION,
            },
            body: JSON.stringify({
                model: this.config.modelName,
                system: systemInstruction,
                messages,
                stream: false,
                max_tokens: 4096,
            }),
        });

        if (!response.ok) {
            await this.handleErrorResponse(response);
        }

        const result = await response.json();
        const content = result.content?.[0]?.text;
        if (content) {
            return content;
        }
        throw new Error(`Invalid response structure from Anthropic API.`);
    }
}
