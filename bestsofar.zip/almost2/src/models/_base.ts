
import { ModelConfig } from '../types';

export interface LLMClient {
    config: ModelConfig;
    generate(
        history: { role: string; parts: { text: string }[] }[],
        systemInstruction: string,
    ): Promise<string>;
}
