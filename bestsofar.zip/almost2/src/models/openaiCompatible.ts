
import { OpenAIConfig, GroqConfig, Role, CloudProvider, MetaConfig, OtherConfig, GeminiConfig } from "../types";
import { LLMClient } from "./_base";

type OpenAICompatibleConfig = OpenAIConfig | GroqConfig | MetaConfig | OtherConfig | GeminiConfig;

const OPENAI_API_BASE = 'https://api.openai.com/v1';
const GROQ_API_BASE = 'https://api.groq.com/openai/v1';

export class OpenAICompatibleClient implements LLMClient {
    public config: OpenAICompatibleConfig;
    private baseUrl: string;

    constructor(config: OpenAICompatibleConfig) {
        if (!config.apiKey) {
          throw new Error(`${config.provider} API key is not configured.`);
        }
        this.config = config;

        switch(config.provider) {
            case CloudProvider.OPENAI:
                this.baseUrl = (config as OpenAIConfig).baseUrl || OPENAI_API_BASE;
                break;
            case CloudProvider.GROQ:
                this.baseUrl = GROQ_API_BASE;
                break;
            case CloudProvider.GEMINI: 
            case CloudProvider.META:
            case CloudProvider.OTHER:
                const customConfig = config as MetaConfig | OtherConfig | GeminiConfig;
                if (!customConfig.baseUrl) {
                    throw new Error(`${config.provider} provider requires a Base URL to be configured.`);
                }
                this.baseUrl = customConfig.baseUrl;
                break;
            default:
                const _exhaustiveCheck: never = config;
                throw new Error(`Invalid provider for OpenAICompatibleClient: ${(_exhaustiveCheck as any).provider}`);
        }
    }

    private transformHistory(history: { role: string; parts: { text: string }[] }[]) {
        return history.map(h => ({
            role: h.role === Role.ASSISTANT ? 'assistant' : 'user',
            content: h.parts.map(p => p.text).join('\n')
        }));
    }

    private async handleErrorResponse(response: Response) {
        let errorBody = await response.text();
        try {
            const errorJson = JSON.parse(errorBody);
            if (errorJson.error && errorJson.error.message) {
                errorBody = errorJson.error.message;
            }
        } catch (e) { /* Not a JSON error, use the raw text */ }
        const statusText = response.status === 401 ? ' (Invalid API Key?)'
                         : response.status === 429 ? ' (Rate Limit Exceeded)'
                         : '';
        throw new Error(`${this.config.provider} API error (${response.status}${statusText}): ${errorBody}`);
    }
    
    async generate(
        history: { role: string; parts: { text: string }[] }[],
        systemInstruction: string
    ): Promise<string> {
        const messages = this.transformHistory(history);
        const response = await fetch(`${this.baseUrl}/chat/completions`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${this.config.apiKey}`
            },
            body: JSON.stringify({
                model: this.config.modelName,
                messages: [
                    { role: 'system', content: systemInstruction },
                    ...messages,
                ],
                stream: false,
            }),
        });

        if (!response.ok) {
            await this.handleErrorResponse(response);
        }

        const result = await response.json();
        const content = result.choices?.[0]?.message?.content;
        if (content) {
            return content;
        }
        throw new Error(`Invalid response structure from ${this.config.provider} chat API.`);
    }
}
