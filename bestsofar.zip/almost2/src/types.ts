
export enum Role {
  USER = 'user',
  ASSISTANT = 'assistant',
  SYSTEM = 'system',
  TOOL = 'tool',
}

export enum AIModelType {
  CLOUD = 'Cloud',
  LOCAL = 'Local',
}

export enum CloudProvider {
    GEMINI = 'Gemini',
    OPENAI = 'OpenAI',
    GROQ = 'Groq',
    ANTHROPIC = 'Anthropic',
    META = 'Meta',
    OTHER = 'Other',
}

export interface GeminiConfig {
    type: AIModelType.CLOUD;
    provider: CloudProvider.GEMINI;
    apiKey: string;
    modelName: string;
    baseUrl?: string;
}

export interface OpenAIConfig {
    type: AIModelType.CLOUD;
    provider: CloudProvider.OPENAI;
    apiKey: string;
    modelName: string;
    baseUrl?: string;
}

export interface GroqConfig {
    type: AIModelType.CLOUD;
    provider: CloudProvider.GROQ;
    apiKey: string;
    modelName: string;
}

export interface AnthropicConfig {
    type: AIModelType.CLOUD;
    provider: CloudProvider.ANTHROPIC;
    apiKey: string;
    modelName: string;
}

export interface MetaConfig {
    type: AIModelType.CLOUD;
    provider: CloudProvider.META;
    apiKey: string;
    modelName: string;
    baseUrl: string;
}

export interface OtherConfig {
    type: AIModelType.CLOUD;
    provider: CloudProvider.OTHER;
    apiKey: string;
    modelName: string;
    baseUrl: string;
}

export type CloudConfig = GeminiConfig | OpenAIConfig | GroqConfig | AnthropicConfig | MetaConfig | OtherConfig;

export interface LocalConfig {
    type: AIModelType.LOCAL;
    baseUrl: string;
    modelName: string;
}

export type ModelConfig = CloudConfig | LocalConfig;

export interface ToolCall {
  toolName: string;
  parameters: Record<string, any>;
}

export type HistoryItem = {
    role: Role.USER | Role.ASSISTANT;
    text: string;
};
