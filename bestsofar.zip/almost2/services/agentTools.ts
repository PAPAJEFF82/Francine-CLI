
import * as fs from 'fs/promises';
import * as path from 'path';
import * as os from 'os';
import { exec } from 'child_process';
import { promisify } from 'util';
import { cwd } from 'node:process';
import { GoogleGenAI } from '@google/genai';
import { ModelConfig, CloudProvider, GeminiConfig } from '../types';

const execAsync = promisify(exec);

// --- Tool Implementations ---

async function list_files(dirPath: string): Promise<string> {
  try {
    const resolvedPath = path.resolve(cwd(), dirPath);
    const files = await fs.readdir(resolvedPath, { withFileTypes: true });
    if (files.length === 0) {
        return `Directory '${dirPath}' is empty.`;
    }
    return files.map(file => (file.isDirectory() ? `${file.name}/` : file.name)).join('\n');
  } catch (error: any) {
    if (error.code === 'ENOENT') {
      return `Error: Directory not found at '${dirPath}'`;
    }
    return `Error listing files: ${error.message}`;
  }
}

async function read_file(filePath: string): Promise<string> {
  try {
    const resolvedPath = path.resolve(cwd(), filePath);
    return await fs.readFile(resolvedPath, 'utf-8');
  } catch (error: any) {
    if (error.code === 'ENOENT') {
      return `Error: File not found at '${filePath}'`;
    } else if (error.code === 'EISDIR') {
        return `Error: Path '${filePath}' is a directory, not a file.`;
    }
    return `Error reading file: ${error.message}`;
  }
}

async function execute_shell_command(command: string): Promise<string> {
  if (!command) {
      return "Error: No command provided to execute.";
  }
  
  try {
    // This is powerful and can be dangerous. The user is warned in the README.
    const { stdout, stderr } = await execAsync(command, { cwd: cwd() });
    if (stderr) {
      return `Execution finished with standard error.\nSTDERR:\n${stderr}\n\nSTDOUT:\n${stdout || '(No standard output)'}`;
    }
    return stdout || "Command executed successfully with no output.";
  } catch (error: any) {
    // error object from exec often contains stdout and stderr, which is useful context for the agent
    let errorMessage = `Error executing command: "${command}".\n`;
    if (error.stderr) errorMessage += `STDERR: ${error.stderr}\n`;
    if (error.stdout) errorMessage += `STDOUT: ${error.stdout}\n`;
    errorMessage += `MESSAGE: ${error.message}`;
    return errorMessage;
  }
}

async function generate_image(prompt: string, config: ModelConfig): Promise<string> {
    if (config.type !== 'Cloud' || config.provider !== CloudProvider.GEMINI || !config.apiKey) {
        return "Error: Image generation is only supported for the Gemini provider with a valid API key.";
    }
    const geminiConfig = config as GeminiConfig;

    try {
        const ai = new GoogleGenAI({apiKey: geminiConfig.apiKey});
        const response = await ai.models.generateImages({
            model: 'imagen-3.0-generate-002',
            prompt,
            config: {
              numberOfImages: 1,
              outputMimeType: 'image/png'
            },
        });

        const base64Image = response.generatedImages?.[0]?.image?.imageBytes;
        if (!base64Image) {
            return "Error: The image generation API did not return an image.";
        }
        
        const desktopPath = path.join(os.homedir(), 'Desktop');
        // Ensure Desktop directory exists, especially in containerized/unusual environments.
        await fs.mkdir(desktopPath, { recursive: true }); 

        const filename = `francine-image-${Date.now()}.png`;
        const imagePath = path.join(desktopPath, filename);
        await fs.writeFile(imagePath, base64Image, 'base64');

        return `Image successfully generated and saved to the user's Desktop at: ${imagePath}`;
    } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
        return `Error during image generation: ${errorMessage}`;
    }
}


const availableTools: { [key: string]: (params: any, config: ModelConfig) => Promise<string> } = {
  list_files: (params) => list_files(params.path),
  read_file: (params) => read_file(params.path),
  execute_shell_command: (params) => execute_shell_command(params.command),
  generate_image: (params, config) => generate_image(params.prompt, config),
};

export async function executeTool(toolName: string, parameters: Record<string, any>, modelConfig: ModelConfig): Promise<string> {
  const tool = availableTools[toolName];
  if (!tool) {
    return `Error: Tool "${toolName}" not found.`;
  }
  try {
    return await tool(parameters, modelConfig);
  } catch (error) {
    return error instanceof Error ? `Error executing ${toolName}: ${error.message}` : `An unknown error occurred in ${toolName}.`;
  }
}