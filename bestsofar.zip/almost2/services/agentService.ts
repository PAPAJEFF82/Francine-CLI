
import { ModelConfig, Role, ToolCall, HistoryItem } from '../types';
import { generateAgentResponse } from './modelRouter';
import { executeTool } from './agentTools';
import { AGENT_SYSTEM_PROMPT } from '../constants';
import chalk from 'chalk';
import { stdout } from 'node:process';

const MAX_AGENT_ITERATIONS = 10;

function isToolCall(obj: any): obj is ToolCall {
    return obj && typeof obj.toolName === 'string' && typeof obj.parameters === 'object';
}

/**
 * Parses the raw text response from the model to extract a thought and a tool call.
 * This parser is designed to be robust against common model output variations.
 * @param responseText The raw text from the model.
 * @returns An object containing the extracted thought and tool call.
 */
function parseAgentResponse(responseText: string): { thought: string | null; toolCall: ToolCall | null } {
    const thoughtMatch = responseText.match(/<thought>([\s\S]*?)<\/thought>/s);
    const thought = thoughtMatch ? thoughtMatch[1].trim() : null;

    // Extract content outside the thought block.
    let actionText = thought ? responseText.substring(responseText.indexOf('</thought>') + 10) : responseText;
    actionText = actionText.trim();

    // Look for a JSON block, which might be wrapped in markdown backticks.
    const jsonRegex = /(?:```json\s*)?({[\s\S]+?})(?:\s*```)?$/;
    const jsonMatch = actionText.match(jsonRegex);

    if (jsonMatch && jsonMatch[1]) {
        try {
            const parsedJson = JSON.parse(jsonMatch[1]);
            if (isToolCall(parsedJson)) {
                return { thought, toolCall: parsedJson };
            }
        } catch (e) {
            // It looked like JSON but wasn't valid. Treat the text as a final answer.
             return { thought, toolCall: { toolName: 'finish', parameters: { response: actionText } } };
        }
    }
    
    // If no valid tool call JSON is found, but there is text, treat it as the final answer.
    if (actionText) {
        return { thought, toolCall: { toolName: 'finish', parameters: { response: actionText } } };
    }

    // If there's only a thought and no action, the model's response is incomplete.
    return { thought, toolCall: null };
}


export async function runAgentLoop(
  history: HistoryItem[],
  modelConfig: ModelConfig,
  showThoughts: boolean
): Promise<string | null> {
  
  // Convert the simple history to the format the LLM expects
  let currentHistory: { role: string; parts: { text: string }[] }[] = history.map(h => ({ role: h.role, parts: [{ text: h.text }] }));

  for (let i = 0; i < MAX_AGENT_ITERATIONS; i++) {
    try {
        if (showThoughts) {
            stdout.write(chalk.gray('Agent is thinking...'));
        }
        
        const responseText = await generateAgentResponse(currentHistory, AGENT_SYSTEM_PROMPT, modelConfig);
        
        if (showThoughts) {
             stdout.write('\r' + ' '.repeat(22) + '\r'); // Clear the "thinking" message
        }
        
        const { thought, toolCall } = parseAgentResponse(responseText);

        if (showThoughts && thought) {
            console.log(chalk.yellow('\n🤔 THOUGHT: ') + chalk.gray(thought));
        }
        
        // Add the full model response to history for context
        currentHistory.push({ role: Role.ASSISTANT, parts: [{ text: responseText }] });

        if (toolCall) {
            if (toolCall.toolName === 'finish') {
                return toolCall.parameters.response || "Agent finished with no response.";
            }

            if (showThoughts) {
                const params = JSON.stringify(toolCall.parameters);
                console.log(chalk.blue('⚡️ ACTION: ') + chalk.cyan(toolCall.toolName) + ' with params ' + chalk.magenta(params));
                stdout.write(chalk.gray(`Executing ${toolCall.toolName}...`));
            }
            
            const toolOutput = await executeTool(toolCall.toolName, toolCall.parameters, modelConfig);
            
             if (showThoughts) {
                stdout.write('\r' + ' '.repeat(toolCall.toolName.length + 15) + '\r'); // Clear the "executing" message
                console.log(chalk.green('✔️ RESULT: ') + chalk.gray(toolOutput.length > 500 ? toolOutput.substring(0, 500) + '...' : toolOutput));
            }
            
            // Add tool result to history for the next loop
            const toolResultText = `<tool_result>\n${toolOutput}\n</tool_result>`;
            currentHistory.push({ role: Role.TOOL, parts: [{ text: toolResultText }] });

        } else {
            console.log(chalk.red("\nAgent Error: Could not determine a valid next action or final answer."));
            if (showThoughts) {
                console.log(chalk.gray("Full model response:\n"), responseText);
            }
            return null;
        }
    } catch (error) {
        if (showThoughts) {
            stdout.write('\r' + ' '.repeat(22) + '\r');
        }
        const errorMessage = error instanceof Error ? error.message : String(error);
        console.error(chalk.redBright('\nAn error occurred during the agent loop: ' + errorMessage));
        return `An error occurred: ${errorMessage}`;
    }
  }

  console.log(chalk.red(`\nAgent reached maximum iterations (${MAX_AGENT_ITERATIONS}) without finishing. Aborting.`));
  return null;
}